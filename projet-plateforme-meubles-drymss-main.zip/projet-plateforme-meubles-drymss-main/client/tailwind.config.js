/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,ts}"],
  theme: {
    extend: {
      colors: {
        fuckingray: "#677c61",
        fuckingbrown: "#a6734d",
      },
    },
  },
  plugins: [],
};
